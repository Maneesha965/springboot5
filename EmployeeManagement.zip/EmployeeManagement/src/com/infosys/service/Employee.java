package com.infosys.service;

public class Employee {
	private int id;
	private String name;
	private double monthlySalary;

	public Employee() {
		super();
	}

	public Employee(int id, String name, double monthlySalary) {
		super();
		this.id = id;
		this.name = name;
		this.monthlySalary = monthlySalary;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getMonthlySalary() {
		return monthlySalary;
	}

	public void setMonthlySalary(double monthlySalary) {
		this.monthlySalary = monthlySalary;
	}

	@Override
	public String toString() {
		return "Id = " + id + ", Name = " + name + ", Monthly Salary = " + monthlySalary;
	}

}
