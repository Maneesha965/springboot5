package com.infosys.service;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;

public class EmployeeService extends Exception{
	EmployeeService employeeService;
	@BeforeAll
    public static void setupAll() {
        System.out.println("Before all tests: Setting up resources for the test suite");
    }

    @BeforeEach
    public void setup() {
        System.out.println("Before each test: Creating an instance of EmployeeService");
        employeeService = new EmployeeService();
    }

    @AfterEach
    public void teardown() {
        System.out.println("After each test: Cleaning up resources");
        employeeService = null;
    }

    @AfterAll
    public static void teardownAll() {
        System.out.println("After all tests: Cleaning up resources for the test suite");
    }
	public double calculateYearlySalary(Employee employee) {
		double yearlySalary = 0;
		yearlySalary = employee.getMonthlySalary() * 12;
		return yearlySalary;
	}

	public double calculateHike(Employee employee) throws Exception {
		double hike = 0;
		if(employee.getMonthlySalary()==0) {
			throw new Exception("salary can't be Zero");
		}
		else if (employee.getMonthlySalary() < 10000) {
			hike = 2000;
		} else {
			hike = 1000;
		}
		return hike;
	}
}
