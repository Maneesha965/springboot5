package com.infosys.test;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;

import com.infosys.client.EmployeeClient;
import com.infosys.service.Employee;
import com.infosys.service.EmployeeService;

public class CalculatorTest extends EmployeeClient{
	EmployeeService employeeService;
	Employee emp=new Employee(1, "Abhishek", 10000);
	 @Test
	    @DisplayName("Test for calculateSalary method")
	    public void testCalculateSalary() {
			double actualSalary = employeeService.calculateYearlySalary(emp);
	        double expectedSalary=10000;
			assertEquals(expectedSalary, actualSalary, "Salary calculation is incorrect.");
	    }
	 
	 @Test
	    @DisplayName("Test for calculateHike method")
	    public void testCalculateHike() throws Exception {

	        double expectedHike = 10000;
	        double actualHike = employeeService.calculateHike(emp);
	        assertEquals(expectedHike, actualHike, "Hike calculation is incorrect.");
	    }
	 @Test
	    @DisplayName("Test for calculateSalary method")
	    public void testInvalidCalculateSalary() {
			double actualSalary = employeeService.calculateYearlySalary(emp);
	        double expectedSalary=10000;
			assertEquals(expectedSalary, actualSalary, "Salary calculation is incorrect.");
	    }
	 @Test
	    @DisplayName("Test for calculateHike method")
	    public void testInvalidCalculateHike() throws Exception {

	        double expectedHike = 10000;
	        double actualHike = employeeService.calculateHike(emp);
	        assertEquals(expectedHike, actualHike, "Hike calculation is incorrect.");
	    }
	 @ParameterizedTest
	    @CsvFileSource(resources = "/test_data.csv", numLinesToSkip = 1)
	    public void testCalculateYearlySalary(int id,String name, double monthlySalary) {
	        Employee employee = new Employee(1, "Abhishek", 10000);
	        double actualYearlySalary = employeeService.calculateYearlySalary(employee);
	        double expectedYearlySalary =30000;
	        assertEquals(expectedYearlySalary, actualYearlySalary, "Yearly salary calculation is incorrect.");
	    }
	}
	 
