package com.infy;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.infy.dto.EmployeeDTO;
import com.infy.service.EmployeeServiceImpl;
import com.infy.util.SpringConfiguration;

public class Client 
{
    public static void main( String[] args )
    {
       AbstractApplicationContext context = new AnnotationConfigApplicationContext(SpringConfiguration.class);
        
        EmployeeServiceImpl service = (EmployeeServiceImpl) context.getBean("employeeService");
       EmployeeServiceImpl serviceNew = context.getBean(EmployeeServiceImpl.class);
       EmployeeDTO employee=new EmployeeDTO();
       employee.setEmpId(1002);
       employee.setName("Maneesha");
       employee.setDepartment("Dev");
        service.insert(employee);
        service.delete(employee.getEmpId());
		
        context.close();
        
    }
}
