package com.infy.service;

import org.springframework.stereotype.Component;

import com.infy.dto.EmployeeDTO;
@Component
public interface EmployeeService {

	public void insert(EmployeeDTO employee);
	
	public void delete(int empId);

}