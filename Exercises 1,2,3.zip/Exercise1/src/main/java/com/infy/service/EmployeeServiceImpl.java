package com.infy.service;

import org.springframework.stereotype.Component;

import com.infy.dto.EmployeeDTO;
@Component
public class EmployeeServiceImpl implements EmployeeService {

	public void insert(EmployeeDTO employee) {
//      Uncomment this code after writing DTO class
		System.out.println("Employee: "+employee.getEmpId()+" added successfully");
	}

	public void delete(int empId) {
//      Uncomment this code after writing DTO class		
	System.out.println("Employee: "+empId+" deleted successfully");
	}


}
