package com.infy.util;



import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.infy.service.EmployeeService;
import com.infy.service.EmployeeServiceImpl;

@Configuration
public class SpringConfiguration {
	@Bean
    public EmployeeService employeeService() {
        return new EmployeeServiceImpl();
    }
}
