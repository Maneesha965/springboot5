package com.infy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.infy.dto.EmployeeDTO;
import com.infy.repository.EmployeeRepository;
@Component
public class EmployeeServiceImpl implements EmployeeService {
	
	private EmployeeRepository employeeRepository;
	 @Autowired
	    public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
	        this.employeeRepository = employeeRepository;
	    }

	/*
		Write code to inject the bean employeeRepository with the help of constructor
	*/	
	public void insert(EmployeeDTO employee) {
		employeeRepository.insertEmployee(employee);
	}

	public void delete(int empId) {
		employeeRepository.removeEmployee(empId);
	}
	
	public List<EmployeeDTO> getAllCustomer() {
		return employeeRepository.fetchCustomer();
	}


}
