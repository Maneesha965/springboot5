package com.infy.validator;

import com.infy.dto.TraineeDTO;
import com.infy.exception.InfyDASystemException;


public class Validator {


	public static void validate(TraineeDTO trainee) throws InfyDASystemException {
		 validateTraineePhoneNo(trainee.getPhoneNo());

	}

	public static Boolean validateTraineePhoneNo(String phoneNo) throws InfyDASystemException {
		if (phoneNo == null || phoneNo.length() != 10) {
            throw new InfyDASystemException("Validator.INVALID_DETAILS");
        }

        char firstDigit = phoneNo.charAt(0);
        if (firstDigit != '7' && firstDigit != '8' && firstDigit != '9') {
            throw new InfyDASystemException("Validator.INVALID_DETAILS");
        }

        return true;
	}
}

