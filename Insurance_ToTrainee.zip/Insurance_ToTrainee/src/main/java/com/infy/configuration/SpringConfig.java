package com.infy.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.infy.repository.InsuranceRepository;
import com.infy.repository.InsuranceRepositoryImpl;
import com.infy.service.InsuranceService;
import com.infy.service.InsuranceServiceImpl;


@Configuration
public class SpringConfig {
	@Bean
    public InsuranceService insuranceService() {
        return new InsuranceServiceImpl();
    }

    @Bean
    public InsuranceRepository insuranceRepository() {
        return new InsuranceRepositoryImpl();
    }
	
	
}