package com.infy.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.infy.exception.InsuranceException;
import com.infy.model.PolicyDTO;
import com.infy.model.PolicyReportDTO;
import com.infy.repository.InsuranceRepository;
import com.infy.validator.Validator;

public class InsuranceServiceImpl implements InsuranceService{
	private InsuranceRepository insuranceRepository;

    @Autowired
    public void setInsuranceRepository(InsuranceRepository insuranceRepository) {
        this.insuranceRepository = insuranceRepository;
    }


	public String buyPolicy(PolicyDTO policy) throws InsuranceException {
		 Validator.validate(policy);
	        return insuranceRepository.buyPolicy(policy);
	}

	public Long calculateAge(LocalDate dateOfBirth) throws InsuranceException {
		 return LocalDate.now().toEpochDay() - dateOfBirth.toEpochDay();
	}

	public List<PolicyReportDTO> getReport(String policyType) throws InsuranceException {
		List<PolicyDTO> allPolicies = insuranceRepository.getAllPolicyDetails();
        List<PolicyDTO> filteredPolicies = new ArrayList<>();

        for (PolicyDTO policy : allPolicies) {
            if (policy.getPolicyType().equals(policyType)) {
                filteredPolicies.add(policy);
            }
        }

        List<PolicyReportDTO> report = new ArrayList<>();
        for (PolicyDTO policy : filteredPolicies) {
            PolicyReportDTO policyReportDTO = new PolicyReportDTO();
            policyReportDTO.setPolicyNumber(policy.getPolicyNumber());
            policyReportDTO.setPolicyHolderName(policy.getPolicyHolderName());
            policyReportDTO.setPolicyHolderAge((double)calculateAge(policy.getDateOfBirth()));
            report.add(policyReportDTO);
        }
        return report;
	}

		
	
	
}
