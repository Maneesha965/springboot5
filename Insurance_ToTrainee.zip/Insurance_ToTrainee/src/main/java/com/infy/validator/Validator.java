package com.infy.validator;

import java.time.LocalDate;
import java.util.regex.Pattern;

import com.infy.exception.InsuranceException;
import com.infy.model.PolicyDTO;

public class Validator {


	public static void validate(PolicyDTO policy) throws InsuranceException{
		 validatePolicyNumber(policy.getPolicyNumber(), policy.getPolicyType());
	        validatePolicyHolderName(policy.getPolicyHolderName());
	        validateDateOfBirth(policy.getDateOfBirth());
	        validatePolicyName(policy.getPolicyName());
	        validatePolicyType(policy.getPolicyType());
	        validatePremium(policy.getPremium());
	        validateTenure(policy.getTenureInMonths());
		
	}

	
	public static Boolean validatePolicyName(String policyName){

		return Pattern.matches("[A-Za-z]+", policyName);

	}
	
	public static Boolean validatePolicyType(String policyType){

		return policyType.equals("Term Life Insurance")
                || policyType.equals("Whole Life Policy")
                || policyType.equals("Endowment Plans");

	}
	
	public static Boolean validatePremium(Double premium){

		return premium > 100;
	}	
	public static Boolean validateTenure(Integer tenureInMonths){

		return tenureInMonths > 24;

	}

	
	public static Boolean validateDateOfBirth(LocalDate dateOfBirth){

		return  dateOfBirth.isBefore(LocalDate.now());

	}

	
	public static Boolean validatePolicyNumber(String policyNumber,String policyType){

		 String regex = getRegexForPolicyType(policyType);
	        return Pattern.matches(regex, policyNumber);

	}

	
	private static String getRegexForPolicyType(String policyType) {
		switch (policyType) {
        case "Term Life Insurance":
            return "TL-\\d{6}";
        case "Whole Life Policy":
            return "WL-\\d{6}";
        case "Endowment Plans":
            return "EP-\\d{6}";
        default:
            return "";
		}

	}


	public static Boolean validatePolicyHolderName(String policyHolderName){

		return Pattern.matches("^\\p{L}{3,}(?: \\p{L}{3,})*$", policyHolderName);

	}
}
